# Twemoji graphics

Twemoji 17.0.3 graphics by the Twemoji contributors:
https://github.com/jdecked/twemoji

Licensed under CC-BY 4.0; see `LICENSE-GRAPHICS`.
